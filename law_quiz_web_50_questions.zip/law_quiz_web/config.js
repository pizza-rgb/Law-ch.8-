// ใส่ Supabase Project URL และ anon public key ของคุณ
window.SUPABASE_URL="YOUR_SUPABASE_URL";
window.SUPABASE_ANON_KEY="YOUR_SUPABASE_ANON_KEY";
